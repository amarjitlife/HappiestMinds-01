
Article:
    https://medium.com/@blackhorseya/crud-operations-with-gorm-in-go-a-comprehensive-guide-eb3cfdf7a22a

Reference:
- https://gorm.io/docs/
- https://github.com/blackhorseya/godine
- https://github.com/blackhorseya/golang-101/tree/main/simple-gorm-mariadb

