
class Human:
	def __init__( self, id, name, dance ):
		self.id 	= id
		self.name 	= name
		self.dance = dance

	def doDance( self ):
		print(f"Doing Dance: {self.id} { self.name}" )

	def hostelLife( self, drinks ):
		self.drinks = drinks

gabbar = Human(420, "Gabbar Singh", "Bhangra! Oye Hoye!!!")
gabbar.doDance()
gabbar.hostelLife("Wisky")

print( gabbar.drinks )
