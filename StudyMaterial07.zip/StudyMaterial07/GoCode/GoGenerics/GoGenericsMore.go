
package main

import "fmt"
import "golang.org/x/exp/constraints"

//________________________________________________________________

// import "constraints"

func Min[T constraints.Ordered](s []T) T {
    if len(s) == 0 {
        panic("empty slice")
    }

    min := s[0]
    for _, v := range s {
        if v < min {
            min = v
        }
    }
    return min
}

func playWithGenericMin() {
    intSlice := []int{3, 1, 4, 2}
    floatSlice := []float64{3.14, 1.61, 4.67, 2.71}

    fmt.Println(Min[int](intSlice))         // Output: 1
    fmt.Println(Min[float64](floatSlice))   // Output: 1.61
}
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithGenericMin")
	playWithGenericMin()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


/*
_____________________________________________________________________
// Go Generics Tutorial
	https://www.digitalocean.com/community/tutorials/how-to-use-generics-in-go
_____________________________________________________________________
Codebunk Link:

https://codebunk.com/b/7211100682491/
https://codebunk.com/b/7211100682491/
_____________________________________________________________________
*/

