
// DESIGN PRACTICE
//		Always Prefer Composition Over Inheritance
//_______________________________________________________

// Abstract Type = { Operations, Phi }
//	Superpower Type
//		Operations = { fly, saveWorld }
//		Range = Phi

interface Superpower {
	public void fly();
	public void saveWorld();
}

//_______________________________________________________

class Spiderman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Spiderman!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

class Superman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Superman!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!"); }
}

class Heman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Heman!"); }
	public void saveWorld() { System.out.println("Save World Like Heman!"); }
}

class Wonderwoman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Wonderwoman!"); }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman!"); }
}

class HanumanJi implements Superpower {
	public void fly() 		{ System.out.println("Fly Like HanumanJi!"); }
	public void saveWorld() { System.out.println("Save World Like HanumanJi!"); }	
}

//_______________________________________________________
//
// Using Mechanism: Inheritance
// class Human {
// class Human extends Spiderman {
// class Human extends Superman {
class Human extends Heman {
	public void fly() 		{ super.fly(); }
	public void saveWorld() { super.saveWorld(); }
}

//_______________________________________________________
// Using Mechanism: Composition
class HumanBetter {
	// Wonderwoman power = null;
	Spiderman power = null;
	// Superman power = null;
	// Heman power = null;
	public void fly() 		{ if ( power != null ) power.fly(); }
	public void saveWorld() { if ( power != null ) power.saveWorld(); }
}

//_______________________________________________________

class HumanBest {
	Superpower power = null;
	public void fly() 		{ if ( power != null ) power.fly(); }
	public void saveWorld() { if ( power != null ) power.saveWorld(); }
}

//_______________________________________________________

class Experiments {

	public static void playWithPower() {
		Spiderman spider = new Spiderman();
		spider.fly();
		spider.saveWorld();

		Superman superman = new Superman();
		superman.fly();
		superman.saveWorld();	

		Heman heman = new Heman();
		heman.fly();
		heman.saveWorld();	

		Wonderwoman wonder = new Wonderwoman();
		wonder.fly();
		wonder.saveWorld();
	}

	public static void playWithHuman() {
		Human h = new Human();
		h.fly();
		h.saveWorld();		
	}

	public static void playWithHumanBetter() {
		HumanBetter hb = new HumanBetter();

		hb.power = new Spiderman();
		hb.fly();
		hb.saveWorld();		

		// hb.power = new Wonderwoman();
		// hb.fly();
		// hb.saveWorld();		
	}

	public static void playWithHumanBest() {
		HumanBest hb = new HumanBest();

		hb.power = new Spiderman();
		hb.fly();
		hb.saveWorld();		

		hb.power = new Superman();
		hb.fly();
		hb.saveWorld();		

		hb.power = new Heman();
		hb.fly();
		hb.saveWorld();		

		hb.power = new Wonderwoman();
		hb.fly();
		hb.saveWorld();		

		hb.power = new HanumanJi();
		hb.fly();
		hb.saveWorld();				
	}

	public static void sayHello() {
		System.out.println("Hello World!");		
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction: sayHello");
		sayHello();

		System.out.println("\nFunction: playWithPower");
		playWithPower();

		System.out.println("\nFunction: playWithHuman");
		playWithHuman();

		System.out.println("\nFunction: playWithHumanBetter");
		playWithHumanBetter();

		System.out.println("\nFunction: playWithHumanBest");
		playWithHumanBest();
	}
}

