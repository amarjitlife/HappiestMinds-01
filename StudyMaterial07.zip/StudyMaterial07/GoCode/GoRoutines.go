
package main

import (
	"fmt"
	"time"
)

//________________________________________________________________

func doSomething( from string ) {
	for i := 0 ; i < 3 ; i++ {
		fmt.Println( from, " : ", i )
		time.Sleep( time.Second * 2 )
	}
}

// func playWithGoRoutines() {
func main() {
	fmt.Println( time.Now().Format( time.RFC850 ) )

	// doSomething("Oye Hoyee!!!") 				// Blocking Function Call
	// doSomething("Ye Dil Maange More!!!") 	// Blocking Function Call

	go doSomething("Oye Hoyee!!!")  			// Non Blocking Function Call
	go doSomething("Ye Dil Maange More!!!") 	// Non Blocking Function Call

	fmt.Println( time.Now().Format( time.RFC850 ) )
	fmt.Println("Done")

	time.Sleep( time.Second * 10 )
// }
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

// func main() {
// 	fmt.Println("\nFunction: playWithGoRoutines")
// 	playWithGoRoutines()

// 	// fmt.Println("\nFunction: ")
// 	// fmt.Println("\nFunction: ")
// 	// fmt.Println("\nFunction: ")
// 	// fmt.Println("\nFunction: ")
// 	// fmt.Println("\nFunction: ")
// 	// fmt.Println("\nFunction: ")
// 	// fmt.Println("\nFunction: ")
// }


/*
_____________________________________________________________________
Codebunk Link:

https://codebunk.com/b/7211100682491/
https://codebunk.com/b/7211100682491/
_____________________________________________________________________
*/

