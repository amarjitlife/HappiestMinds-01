
package main

import (
	"fmt"
	"bufio"
	"os"
	"strings"
	"strconv"
	"unicode/utf8"
	"unicode"
	"io"
)

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

func removeDuplicates() {
	seen := make(map[string]bool) // a set of strings
	fmt.Println("seen Length: ", len( seen ) )

	input := bufio.NewScanner( os.Stdin )
	
	for input.Scan() {
		line := input.Text()
		if !seen[line] {
			seen[line] = true
			fmt.Println(line)
		}
	}

	if err := input.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "removeDuplicates: %v\n", err)
		os.Exit(1)
	}	

	fmt.Println( seen )
}

//________________________________________________________________

func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ; i < j ; i, j = i + 1, j - 1{
		s[i], s[j] = s[j], s[i]
	}
}

func playWithReadingInputs() {
	input := bufio.NewScanner( os.Stdin )

	outer:
		for input.Scan() {
			var ints []int

			for _, s := range strings.Fields( input.Text() ) {
				x, err := strconv.ParseInt( s, 10, 64 )

				if err != nil {
					fmt.Fprintln( os.Stderr, err )
					continue outer
				}
				ints = append( ints, int( x ) )
			}

			fmt.Printf( "%v\n", ints )
			reverse( ints )
			fmt.Printf( "%v\n", ints)
		}
}


//________________________________________________________________

func countUnicodeCharacters() {
	counts := make(map[rune]int)    // counts of Unicode characters
	var utflen [utf8.UTFMax + 1]int // count of lengths of UTF-8 encodings
	invalid := 0                    // count of invalid UTF-8 characters

	in := bufio.NewReader(os.Stdin)
	for {
		r, n, err := in.ReadRune() // returns rune, nbytes, error
		if err == io.EOF {
			break
		}
		if err != nil {
			fmt.Fprintf(os.Stderr, "charcount: %v\n", err)
			os.Exit(1)
		}
		if r == unicode.ReplacementChar && n == 1 {
			invalid++
			continue
		}
		counts[r]++
		utflen[n]++
	}
	fmt.Printf("rune\tcount\n")
	for c, n := range counts {
		fmt.Printf("%q\t%d\n", c, n)
	}
	fmt.Print("\nlen\tcount\n")
	for i, n := range utflen {
		if i > 0 {
			fmt.Printf("%d\t%d\n", i, n)
		}
	}
	if invalid > 0 {
		fmt.Printf("\n%d invalid UTF-8 characters\n", invalid)
	}
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	// fmt.Println("\nFunction: removeDuplicates")
	// removeDuplicates()

	// fmt.Println("\nFunction: playWithReadingInputs")
	// playWithReadingInputs()

	fmt.Println("\nFunction: countUnicodeCharacters")
	countUnicodeCharacters()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


/*
_____________________________________________________________________
Codebunk Link:

https://codebunk.com/b/5351100681448/
https://codebunk.com/b/5351100681448/
_____________________________________________________________________
*/

