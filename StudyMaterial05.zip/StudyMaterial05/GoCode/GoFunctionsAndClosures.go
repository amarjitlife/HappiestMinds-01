
package main

import (
	"fmt"
	// "math"
)


//________________________________________________________________

func division( dividend, divisor int ) (int, int) {
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func divisionAgain( dividend, divisor int ) (quotient int, remainder int) {
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func playWithDivision() {
	q, r := division(10, 3)
	fmt.Printf("\nQuotient: %d Remainder: %d", q, r )

	qq, rr := divisionAgain(10, 3)
	fmt.Printf("\nQuotienst: %d Remainder: %d", qq, rr )
}

//________________________________________________________________

func playWithClosures() {
	var x, y = 40, 20

	// Anonymous Functions
	//		Closures/Lambdas
	add := func( x, y int ) int { return x + y }
	sub := func( x, y int ) int { return x - y }

	result := add(x, y)
	fmt.Println("Result : ", result)

	result = sub(x, y)
	fmt.Println("Result : ", result)	
}

//________________________________________________________________
// Function Type
//		(int, int) -> int
func sum(x, y int) int { return x + y }
func sub(x, y int) int { return x + y }
func mul(x, y int) int { return x * y }

// Function Type
//		(int, int, (int, int) -> int ) -> int

// Polymorphic Function
//		Takes Multiple Forms
//		Using Mechanism : By Passing Function/Closure To Function
func calculator( x int, y int, operation func(int, int) int ) int {
	return operation(x, y)
}

func playWithCalculator() {
	var a, b = 40, 20
	var result = 0

	result = calculator(a, b, sum)
	fmt.Println("Result : ", result)	

	result = calculator(a, b, sub)
	fmt.Println("Result : ", result)	

	result = calculator(a, b, mul)
	fmt.Println("Result : ", result)	

	sumClosure := func( x, y int ) int { return x + y }
	subClosure := func( x, y int ) int { return x - y }
	mulClosure := func( x, y int ) int { return x * y }

	result = calculator(a, b, sumClosure)
	fmt.Println("Result : ", result)	

	result = calculator(a, b, subClosure)
	fmt.Println("Result : ", result)	

	result = calculator(a, b, mulClosure)
	fmt.Println("Result : ", result)	
}


//________________________________________________________________

func doSomething( x int, y int ) int {
	return x + y + 10
}

func playWithFunctions() {
	a, b := 100, 200
	result := 0

	// var something int
	var something func(int, int) int
	// cannot use doSomething 
	// (value of type func(x int, y int) int) 
	// as int value in assignment
	something = doSomething
	result = something(a, b)
	fmt.Println("Result : ", result)

	// somethingAgain := calculator
	// var somethingAgain int
	// cannot use calculator 
	//	(value of type func(x int, y int, operation func(int, int) int) int) 
	//	as int value in assignment
	var somethingAgain func(int, int, func(int, int) int ) int
	somethingAgain = calculator

	result = somethingAgain(a, b, sum)
	fmt.Println("Result : ", result)
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithDivision")
	playWithDivision()

	fmt.Println("\nFunction: playWithClosures")
	playWithClosures()

	fmt.Println("\nFunction: playWithCalculator")
	playWithCalculator()

	fmt.Println("\nFunction: playWithFunctions")
	playWithFunctions()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


/*
_____________________________________________________________________
Codebunk Link:

https://codebunk.com/b/5351100681448/
https://codebunk.com/b/5351100681448/
_____________________________________________________________________
*/

