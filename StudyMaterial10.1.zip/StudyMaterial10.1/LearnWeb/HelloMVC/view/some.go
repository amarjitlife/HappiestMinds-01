
package view

import "fmt"

func saySomething() {
	fmt.Println("Hello View!!!")
}


func SaySomething() {
	fmt.Println("Hello View!!!")
}
