
package controller

import "fmt"

func saySomething() {
	fmt.Println("Hello! Controller!!!")
}

func SaySomething() {
	fmt.Println("Hello! Controller!!!")
}
