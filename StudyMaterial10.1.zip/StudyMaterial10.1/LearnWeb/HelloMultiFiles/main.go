
package main

import (
	"example.com/multiple/first"
	"example.com/multiple/second"
)

func main() {
	first.HelloDing()
	second.HelloDong()
}

