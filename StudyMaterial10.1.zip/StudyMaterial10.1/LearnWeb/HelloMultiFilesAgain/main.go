
package main

import (
	"example.com/multiple/First"
	"example.com/multiple/firstthing"
	"example.com/multiple/Second"
	// "example.com/multiple/second"
	// main.go:8:2: case-insensitive import collision: 
	//	"example.com/multiple/second" and "example.com/multiple/Second"

)

func main() {
	first.HelloDing()
	second.HelloDong()
	First.HelloDing()
}

