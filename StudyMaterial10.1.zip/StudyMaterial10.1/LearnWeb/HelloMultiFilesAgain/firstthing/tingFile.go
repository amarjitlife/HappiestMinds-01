
package First

import "fmt"

func HelloDing() {
	fmt.Println("Hello Ding!!!")
}

