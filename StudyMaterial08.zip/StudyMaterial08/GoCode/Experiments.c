
#include <stdio.h>

//________________________________________________________________

void playWithArraysAndPointers() {
	int a[5] = {10, 20, 30, 40, 50};
	// printf("\n Something: %d", a[-5] );

	// for( int i = -10 ; i < 10 ; i++ ) {
	// 	printf("\n At Index %d Value : %d", i, a[i]);
	// }

	for( int i = 0 ; i < 5 ; i++ ) {
		// if i < 0 || i > 5 {
		// 	throw IndexOutOfBoundException
		// } else {
			printf("\n At Index %d Value : %d", i, a[i]);
		// }
	}

	int *ptr;
	ptr = a;
	for( int i = 0 ; i < 5 ; i++ ) {
		printf("\n At Index %d Value : %d", i, *(ptr + i) );
	}
}

//________________________________________________________________

int sum( int x, int y ) { return x + y; }
int sub( int x, int y ) { return x - y; }

// Polymorphic Function
//		Using Mechanism: Passing A Behaviour To Behaviour
int calculator( int x, int y, int (*operation)(int, int) ) {
	return operation(x, y);
}

void playWithCalculator() {
	int a = 40, b = 20;
	int result = 0;

	result = calculator( a, b, sum );
	printf("\nResult : %d", result );

	result = calculator( a, b, sub );
	printf("\nResult : %d", result );
}

//________________________________________________________________

typedef struct human_type {
	int id;
	char name[100];	
	void (*dance)();
} Human;

void doBhangra() {
	printf("\nDance: Oyee Hoyeee!!! Balleee Ballleee!!!");
}

void doHipHop() {
	printf("\nDance: Hip Hop Dance...");
}

void playWithHuman() {
					// Constructor
	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID 	: %d", gabbar.id );
	printf("\nName: %s", gabbar.name );
	gabbar.dance();
					// Constructor
	Human basanti = { 100, "Basanti", doHipHop };
	printf("\nID 	: %d", basanti.id );
	printf("\nName: %s", basanti.name );
	basanti.dance();
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

int main() {
	printf("\nFunction: playWithArraysAndPointers");
	playWithArraysAndPointers();

	printf("\nFunction: playWithCalculator");
	playWithCalculator();

	printf("\nFunction: playWithHuman");
	playWithHuman();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");	
}
