
package main

import (
	"fmt"
	"time"
	"sync"
)

//________________________________________________________________

func doSomething( from string ) {
	for i := 0 ; i < 3 ; i++ {
		fmt.Println( from, " : ", i )
		time.Sleep( time.Second * 2 )
	}
}

func playWithGoRoutines() {
// func main() {
	fmt.Println( time.Now().Format( time.RFC850 ) )

	// doSomething("Oye Hoyee!!!") 				// Blocking Function Call
	// doSomething("Ye Dil Maange More!!!") 	// Blocking Function Call

	go doSomething("Oye Hoyee!!!")  			// Non Blocking Function Call
	go doSomething("Ye Dil Maange More!!!") 	// Non Blocking Function Call

	// someClosure := func( message string ) { 
	// func( message string ) { // Blocking Function Call
	go func( message string ) { // Non Blocking Function Call
		for i := 0 ; i < 3 ; i++ {
			fmt.Println( message, " : ", i )
			time.Sleep( time.Second * 2 )
		}
		time.Sleep( time.Second * 3 )
	}("Balleee Balleee!!")
	//}
	//go someClosure("Balleee Balleee!!")

	fmt.Println( time.Now().Format( time.RFC850 ) )
	fmt.Println("Done: playWithGoRoutines")
}

//________________________________________________________________

func playWithChannels() {
	messages := make( chan string )
	var messageRead string

	// <- Symbol Behind Channel Means Writing
	// <- Symbol Before Channel Means Reading
	go func() {
		//	Writing To Channel messages
		messages <- "Ping"
		time.Sleep( time.Second * 2 )
		
		messages <- "Pong"
		time.Sleep( time.Second * 2 )

		messages <- "Ting"
		time.Sleep( time.Second * 2 )

		messages <- "Tong"
		time.Sleep( time.Second * 2 )
		fmt.Println("Done: Closure Go Routine")
	}()

	// Reading From Channel messages
	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	fmt.Println("Done: playWithChannels")
}

//________________________________________________________________

func sum( numbers[] int, messages chan int ) {
	sum := 0
	for _, number := range numbers {
		sum += number
	}

	messages <- sum
}

func playWithSum() {
	numbers := []int{ 1, 2, 9, -9, 4, 0, 7 }
	messages := make( chan int )

	go sum( numbers[ : len( numbers )/2], messages )
	go sum( numbers[ len( numbers )/2 :], messages )

	// The data flows in the direction of the arrow
	sum1, sum2 := <- messages, <- messages
	total := sum1 + sum2
	fmt.Println("Total Sum: ", total )
}

//________________________________________________________________

// pings Is Write Only Channel
func ping( pings chan<- string, data string ) {
	pings <- data
}

// pings Is Read Only Channel
// pongs Is Write Only Channel
func pong( pings <-chan string, pongs chan<- string ) {
	data := <- pings
	pongs <- data
}

func playWithChannelWithReadWriteOnly() {
	pings := make( chan string, 1 )
	pongs := make( chan string, 1 )

	ping( pings, "Ye Dil Maange More!!!")
	pong( pings, pongs)

	fmt.Println( <- pongs )
}

//________________________________________________________________

// One suggestion (made by Rob Pike) for concurrent programming 
// is don't (let computations) communicate by sharing memory, 
// (let them) share memory by communicating (through channels). 
// (We can view each computation as a goroutine in Go programming.)

func worker( done chan bool ) {
	fmt.Println("Worker: Working...")
	time.Sleep( time.Second * 3 )
	fmt.Println("Worker: Work Done!!")

	done <- true
}

func playWithWorkers() {
	done := make( chan bool, 1 )

	go worker( done )
	workerStatus := <- done
	fmt.Println("Worker Status: ", workerStatus)
}


//________________________________________________________________

func playWithClosingChannel() {
	messages := make( chan string, 2 )
	messages <- "Ye Dil Maangee More!!!"
	messages <- "Oyee Hoyeee!!!"

	close( messages )

	// Reading From Channel Using For Loop
	for message := range messages {
		fmt.Println( message )
	}
}

//________________________________________________________________

func fibonacci( count int, fibos chan int ) {
	x, y := 0, 1

	for i := 0 ; i < count ; i++ {
		fibos <- x
		x, y = y, x + y
	}
	close( fibos )
}

func playWithFibonaccis() {
	fibos := make( chan int, 10 )

	go fibonacci( cap( fibos ), fibos )

	for fibo := range fibos {
		fmt.Println( fibo )
	}
} 

//________________________________________________________________

func fibonacciAgain( fibos chan int, quit chan bool ) {
	x, y := 0, 1
	// var order bool
	for {
		select {
		case fibos <- x:
			x, y = y, x + y
		case order := <- quit:
			if order == true {
				fmt.Println("Fibonacci Quit!")
				return
			}
		}
	}
}

func playWithFibonaccisAgain() {
	fibos 	:= make( chan int, 10 )
	quit 	:= make( chan bool )

	go func() {
		for i := 0 ; i < 10 ; i++ {
			fmt.Println( <- fibos )
		}
		quit <- true
	}()
	fibonacciAgain( fibos, quit )
} 

//________________________________________________________________

// import "time"

func playWithTimeTick() {
	tick := time.Tick(100 * time.Millisecond)
	boom := time.After(500 * time.Millisecond)
	for {
		select {
		case <-tick:
			fmt.Println("tick.")
		case <-boom:
			fmt.Println("BOOM!")
			return
		default:
			fmt.Println("    .")
			time.Sleep(50 * time.Millisecond)
		}
	}
}

//________________________________________________________________

// import "sync"

// SafeCounter is safe to use concurrently.
type SafeCounter struct {
	mu sync.Mutex
	v  map[string]int
}

// Inc increments the counter for the given key.
func (c *SafeCounter) Inc(key string) {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	c.v[key]++
	c.mu.Unlock()
}

// Value returns the current value of the counter for the given key.
func (c *SafeCounter) Value(key string) int {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	defer c.mu.Unlock()
	return c.v[key]
}

func playWithSafeCounter() {
	c := SafeCounter{v: make(map[string]int)}
	
	for i := 0; i < 1000; i++ {
		go c.Inc("somekey")
	}

	time.Sleep(time.Second)
	fmt.Println(c.Value("somekey"))
}

//________________________________________________________________
//________________________________________________________________

func main() {
// 	fmt.Println("\nFunction: playWithGoRoutines")
// 	playWithGoRoutines()

	// fmt.Println("\nFunction: playWithChannels")
	// // playWithChannels()
	// go playWithChannels()

	// fmt.Println("\nFunction: playWithSum")
	// playWithSum()

	// fmt.Println("\nFunction: playWithChannelWithReadWriteOnly")
	// playWithChannelWithReadWriteOnly()

	// fmt.Println("\nFunction: playWithWorkers")
	// playWithWorkers()

	// fmt.Println("\nFunction: playWithClosingChannel")
	// playWithClosingChannel()

	// fmt.Println("\nFunction: playWithFibonaccis")
	// playWithFibonaccis()

	fmt.Println("\nFunction: playWithFibonaccisAgain")
	playWithFibonaccisAgain()

	fmt.Println("\nFunction: playWithTimeTick")
	playWithTimeTick()

	fmt.Println("\nFunction: playWithSafeCounter")
	playWithSafeCounter()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")

	time.Sleep( time.Second * 4 )
	fmt.Println("Main Function: Done")
}


/*
_____________________________________________________________________
Codebunk Link:

https://codebunk.com/b/7211100682491/
https://codebunk.com/b/7211100682491/
https://codebunk.com/b/7211100682491/
_____________________________________________________________________
*/

