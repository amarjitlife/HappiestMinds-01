_____________________________________________________________________

DAY 01
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			Chapters 01 to Chapters 10
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

_____________________________________________________________________

DAY 02
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter: Arrays and Pointers

	Assignment A1: Reading, Coding and Practice Assignment
		Book: Learning Go, Oreilly Publication
		Chapter 02, 03 and 04
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Practice And Revise Code Examples 
			Experiment Following Idea In Your Language Of Choice
			and Reason Output

			>>> m = [10, 20, 30]
			>>> n = [100, 200, 300, 400 ]
			>>> m
			[10, 20, 30]
			>>> n
			[100, 200, 300, 400]
			>>> ll = [m , n]
			>>> ll
			[[10, 20, 30], [100, 200, 300, 400]]
			>>> m[0] = 99
			>>> m
			[99, 20, 30]
			>>> n
			[100, 200, 300, 400]
			>>> ll
			[[99, 20, 30], [100, 200, 300, 400]]

_____________________________________________________________________

DAY 03
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment [ REVISE ]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter: Arrays and Pointers

	Assignment A1: Reading, Coding and Practice Assignment
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf and GetProgrammingWithGo-PART2.pdf
			Chapters 01 to Chapters 20
				Read All Chapters
				Practice and Experiments Code Examples'
			
			Solve All Assignments Mentioned In Each Chapter From These
				GetProgrammingWithGo-PART1.pdf
				GetProgrammingWithGo-PART2.pdf
				IntroducingGo.pdf

		Book: Learning Go, Oreilly Publication
		Chapter 02, 03, 04 and 05
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Code Following Excercises 
		Write Quick Sort in Go Lang
		Write Binary Search Algorithm in Go Lang
		LeetCode, HackerRank, HakerEarth Problems In Go Lang
	
	Assignment A4: For Brave Hearts!!! [ Advanced Learners ]
		Read Following Book 
		The Go Programming Language
			by Alan Donovan (Author), Brian Kernighan (Author)
					
_____________________________________________________________________

DAY 04
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment
		Book: Learning Go, Oreilly Publication
			Read Following Chapters
				Chapter 05: Functions
				Chapter 06: Pointers
			Practice and Experiments Chapter Code Examples'
			Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Read Features/Functions in Following Go Packages 
		and Experiment Examples
		https://pkg.go.dev/strings
		https://pkg.go.dev/strconv
		https://pkg.go.dev/bufio
	
	Assignment A4: Practice More Code Examples
		Book: Pro Go By Adam Freeman
		Chapters 03 To 10
			These Chapters Contains A Lot More Code Examples

_____________________________________________________________________

DAY 05
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment
		Book: Learning Go, Oreilly Publication
			Read Following Chapters
				Chapter 05: Functions
				Chapter 06: Pointers
				Chapter 07: Types, Methods and Interfaces				
			Practice and Experiments Chapter Code Examples'
			Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class
	
	Assignment A3: Practice More Code Examples
		Book: Pro Go By Adam Freeman
		Chapters 03 To 10
			These Chapters Contains A Lot More Code Examples

_____________________________________________________________________

DAY 06
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment
		Book: Learning Go, Oreilly Publication
			Read Following Chapters
				Chapter 07: Types, Methods and Interfaces				
			Practice and Experiments Chapter Code Examples'
			Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class
	
	Assignment A3: Practice More Code Examples
		Book: Pro Go By Adam Freeman
			Chapter 11: Using Methods and Interfaces
			Chapter 13: Type and Interface Composition
			Chapter 16: String Processing and Regular Expressions 
			Chapter 20: Reading and Writing Data 
			Chapter 22: Working with Files

			These Chapters Contains A Lot More Code Examples

_____________________________________________________________________

DAY 07
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment
		Book: Learning Go, Oreilly Publication
			Read Following Chapters
				Chapter 07: Types, Methods and Interfaces
				Chapter 08: Errors
				Chapter 09: Modules, Packages, and Imports.		
			Practice and Experiments Chapter Code Examples'
			Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class
	
	Assignment A3: Practice More Code Examples
		Book: Pro Go By Adam Freeman
			Chapter 16: String Processing and Regular Expressions 
			Chapter 20: Reading and Writing Data 
			Chapter 22: Working with Files

			These Chapters Contains A Lot More Code Examples


_____________________________________________________________________

DAY 08
_____________________________________________________________________

	Assignment A0: REVISION
		Revise and Practice Go From
		All Go Language Chapters From
			1. Learning Go
			2. Pro Go

	Assignment A1: Reading, Coding and Practice Assignment
		Book: Learning Go, Oreilly Publication
			Read Following Chapters
				Chapter 10: Concurrency In GO
				Chapter 11: The Standard Library
			Practice and Experiments Chapter Code Examples'
			Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class
	
	Assignment A3: Practice More Code Examples
		Book: Pro Go By Adam Freeman
			Chapter 16: String Processing and Regular Expressions
			Chapter 20: Reading and Writing Data
			Chapter 22: Working with Files
			
			Chapter 19: Dates, Times, and Durations
			Chapter 21: Working with JSON Data
			Chapter 24: Creating HTTP Servers [ Pages: 627 to 651 ]

			These Chapters Contains A Lot More Code Examples

_____________________________________________________________________

DAY 09+10 : MONDAY and TUESDAY
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment

		Book: Pro Go By Adam Freeman
		Read Following Chapters and Practice Code Examples
		   Chapter 19: Dates, Times, and Durations
		   Chapter 21: Working with JSON Data
		   Chapter 24: Creating HTTP Servers [ Pages: 627 to 651 ]
		   Chapter 25: Creating HTTP Clients

	Assignment A2: Reading, Coding and Practice Assignment

		Book: Learning Go, O'reilly Publication
		Read Following Chapters and Practice Code Examples
			Chapter 13. Writing Tests
		  Chapter 15. A Look at the Future: Generics in Go

	Assignment A3: References Of Packages/Frameworks

		https://pkg.go.dev/errors
		https://pkg.go.dev/github.com/gin-gonic/gin
		https://pkg.go.dev/database/sql
		https://pkg.go.dev/github.com/go-sql-driver/mysql


_____________________________________________________________________

DAY 10 : THURSDAY
_____________________________________________________________________

	Assignment A1: Coding, Reasoning and Practice Assignment
			Project: ProjectRunnerMysql
				1. Explore, Understand Project Code
						Identify All Entities
						Understand Role and Responsibilities
						Understand Design Decisions
						Draw Components and Sequence Diagrams
						Understand Libaries Used and Functions

				2. Code This Project From Scratch
						Divide This Project Problem In Small Set Of Problems
						Start Implementing Each Small Part From Scratch
						Build Full Application
_____________________________________________________________________
_____________________________________________________________________
GitHub Repository Link:

https://github.com/amarjitlife/HappiestMinds-01

_____________________________________________________________________
_____________________________________________________________________


