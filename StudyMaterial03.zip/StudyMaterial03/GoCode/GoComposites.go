
package main 

import (
	"fmt"
	"os"
	"bufio"
)

//__________________________________________________________

func playWithTypesAndDefaultValues() {
	// Following Types Are Initialised To Default Values Of 0
	var a int 
	var a8 int8
	var a16 int16
	var a32 int32
	var a64 int64

	aa := 99
	fmt.Println("Value Of aa: ", aa )
	fmt.Printf("Type Of aa: %T \n", aa )

	var ua uint 
	var ua8 uint8
	var ua16 uint16
	var ua32 uint32
	var ua64 uint64

	fmt.Println(a, a8, a16, a32, a64)
	fmt.Println(ua, ua8, ua16, ua32, ua64)

	var f1 float32
	var f2 float64
	fmt.Println( f1, f2 )

	ff := 99.90
	fmt.Println("Value Of ff: ", ff)
	fmt.Printf("Type Of ff: %T \n", ff)

	var some string
	fmt.Println( some )

	greeting := "Good Morning!"
	fmt.Println("Value Of greeting: ", greeting)
	fmt.Printf("Type Of greeting: %T \n", greeting)

	var b bool
	fmt.Println( b )

	var c1 complex64
	fmt.Println( c1 )

	var c2 complex128
	fmt.Println( c2 )
}
	

//__________________________________________________________

func playWithArrays() {
	var a[4]int 

	fmt.Println( a )
	// range Operator Gives
	//		List of Tuples Having 2 Members
	//		First Member Will Be Index
	//		Second Member Will Be Value
	for i, value := range a {
		fmt.Println( i, value )
	}

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[ len( a ) - 1 ] )

// invalid argument: index 4 out of bounds [0:4]
	// fmt.Println( a[ len( a ) ] )	

	// _ Is A Special Variable
	//		Used For Ignoring i.e. Which You Don't Wants To Use
	for _, value := range a {
		fmt.Println( value )
	}

	for index := range a {
		fmt.Println( index, a[ index ] )
	}
}

//__________________________________________________________

func playWithArraysAgain() {
	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length q: ", len( q ) )
	fmt.Println("Array Length r: ", len( r ) )
	fmt.Printf("Array q Type: %T \n ", q )
	fmt.Printf("Array r Type: %T \n", r )

	for index, value := range q {
		fmt.Println("At Index: ", index, " Value: ", value)
	}

	for index, value := range r {
		fmt.Println("At Index: ", index, " Value: ", value)
	}

	// ... Dots Means Size Deduced From Initialisation List

	s := [...]int{10, 20, 30, 99, 100, 111}
	fmt.Println("Array s: ", s )
	fmt.Println("Array Length s: ", len( s ) )
	fmt.Printf("Array q Type: %T \n ", s )
//	fmt.Printf("Array r Type: %T \n", r )

	for index, value := range s {
		fmt.Println("At Index: ", index, " Value: ", value )
	}

	aa := [2]int{ 10, 20 }
	bb := [...]int{ 10, 20 }
	cc := [2]int{ 10, 30 }

	fmt.Println("aa Equals bb: ", aa == bb )	
	fmt.Println("aa Equals cc: ", aa == cc )
	fmt.Println("cc Equals bb: ", cc == bb )

	aaa := [2]int{ 10, 20 }
	bbb := [3]int{ 10, 20 }
	fmt.Println( aaa, bbb )
	// fmt.Println("aaa == bbb : ", aaa == bbb )

	someArray := [...]int{ 0: 11, 3: 33, 7: 77 }
	fmt.Println("someArray : ", someArray )
	fmt.Println("Length Of someArray: ", len( someArray) )
	fmt.Printf("Type Of someArray: %T \n", someArray )

	someArrayAgain := [...]int{ 99: -555 }
	fmt.Println("someArray : ", someArrayAgain )
	fmt.Println("Length Of someArray: ", len( someArrayAgain ) )
	fmt.Printf("Type Of someArray: %T \n", someArrayAgain )

	// Implicit Type Casting Happening
	var some [4]float64 = [4]float64{ 99.90, 88.8, 111, }
	fmt.Println( "some Array: ", some )

	var ii int = 111
	var ff float64 = 99.99
	fmt.Println( ii, ff )
//	var result = ii + ff

	// var someAgain [3]string = [3]string{ "Ding", "Dong", 111 }
	// fmt.Println( "someAgain Array: ", someAgain )	
}

//__________________________________________________________

// Array Elements Are Pass By Values
func changeArray( some [10]int ) {
	fmt.Println("changeArray Function Called...")
	for index, _ := range some {
		some[ index ] = 111
	}
}

// Array Itself Are Also Pass By Value
func changeArrayAgain( some [10]int ) {
	fmt.Println("changeArray Function Called...")
	some = [10]int{11, 11, 11, 11, 11, 11, 11, 11, 11, 11}
}

// Array Pass By Reference
func changeArrayOnceAgain( someAddress *[10]int ) {
	for index, _ := range someAddress {
		someAddress[ index ] = 111
	}
}

// Array Pass By Reference Using Slice
func changeArrayOnceMore( someSlice []int ) {
	for index, _ := range someSlice {
		someSlice[index] = 222
	}
}

func playWithArraysOnceAgain() {
	var aa [10]int = [10]int{10, 20, 30, 40, 50, 60, 70, 80, 90, 100}

	fmt.Println("Value Of aa: ", aa )
	changeArray( aa )
	fmt.Println("Value Of aa: ", aa )

	fmt.Println("Value Of aa: ", aa )
	changeArrayAgain( aa )
	fmt.Println("Value Of aa: ", aa )	

	fmt.Println("Value Of aa: ", aa )
	changeArrayOnceAgain( &aa ) 	// Passing Address Of Array aa
	fmt.Println("Value Of aa: ", aa )	

	fmt.Println("Value Of aa: ", aa )
	// Here aa[ : ] Slice Over Array aa
	changeArrayOnceMore( aa[ : ] ) // Passing Slice Of Array aa
	fmt.Println("Value Of aa: ", aa )		
}


//__________________________________________________________

func playWithArrayAndSlices() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }
	fmt.Println("Array a: ", a)

	some1 := a[ 0 : 4 ]
	fmt.Println("Slice some1: ", some1 )

	some2 := a[ 4 : 9 ]
	fmt.Println("Slice some2: ", some2 )

	some3 := a[ : 5 ]
	fmt.Println("Slice some3: ", some3 )

	some4 := a[ 6 : ]
	fmt.Println("Slice some4: ", some4 )

	some5 := a[ : ]
	fmt.Println("Slice some5: ", some5 )
}

//__________________________________________________________

// Function Taking Slice As Argument
func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ; i < j ; i, j = i + 1, j - 1 {
		s[i], s[j] = s[j], s[i]
	}
}

func playWithArrayAndSlicesAgain() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }
	fmt.Println("Array a: ", a)

	some1 := a[ 0 : 4 ]
	fmt.Println("Array a: ", a )	
	reverse( some1 )
	fmt.Println("Array a: ", a )

	some2 := a[ 4 : 9 ]
	fmt.Println("Array a: ", a )	
	reverse( some2 )
	fmt.Println("Array a: ", a )

	some3 := a[ : ]
	fmt.Println("Array a: ", a )	
	reverse( some3 )
	fmt.Println("Array a: ", a )
}

// Function: playWithArrayAndSlicesAgain
// Array a:  [10 20 30 40 50 60 70 80 90 99]
// Array a:  [10 20 30 40 50 60 70 80 90 99]
// Array a:  [40 30 20 10 50 60 70 80 90 99]
// Array a:  [40 30 20 10 50 60 70 80 90 99]
// Array a:  [40 30 20 10 90 80 70 60 50 99]

/*
	some5 := a[ : ]
	fmt.Println("Array a: ", a )	
	doSomething( some5 )
	fmt.Println("Array a: ", a )
*/

//__________________________________________________________

// Function Taking 2 Slices As Argument
func printCommon( summer []string, quater []string ) {
	for _, summerMonth := range summer {
		for _, quaterMonth := range quater {
			if summerMonth == quaterMonth {
				fmt.Printf("%s Month Appear In Both!", summerMonth)
			}
		}
	}
}

// Following Both Signatures Are Equivalent
// func slicesEqual( x []string, y []string ) bool {
func slicesEqual( x, y []string ) bool {
	if len( x ) != len( y ) {
		return false 
	}

	for index := range x {
		if x[index] != y[index] {
			return false
		}
	}

	return true
}

func playWithArrayAndSlicesOnceAgain() {
	months := [...]string {
		1: "January", 2: "February", 3: "March", 4: "April",
		5: "May", 6: "June", 7: "July", 8: "August",
		9: "September", 10: "October", 11: "November", 12: "December",
	}

	quater2 := months[ 4 : 7] 
	summer := months[ 6 : 9 ]
	fmt.Println( months )
	fmt.Println( quater2 )
	fmt.Println( summer )
	printCommon( summer, quater2 )

	firstThree := months[ 1 : 4   ]
	quater1 := months[ 1 : 4 ]

	// invalid operation: firstThree == quater1 (slice can only be compared to nil)
	// fmt.Println("Slices Are Equal: ", firstThree == quater1 ) 
	result := slicesEqual( firstThree, quater1 )
	fmt.Println("Slices Are Equal: ", result ) 
}
//________________________________________________________________
// 				GO SLICES CONCEPTS
//________________________________________________________________

// Slices represent variable-length sequences whose elements all have the same type. 
// 	A slice type is written []T, where the elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence 
// (or perhaps all) of the elements of an array, which is known as the 
// slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is 
//          reachable through the slice, which is not necessarily the array’s 
//          first element. 
// 		The length is the number of slice elements; it can’t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 
// 		The built-in functions len and cap return those values.


// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 	which may be an array variable, a pointer to an array, or anotherslice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of valid months, 
// 	as does the slice months[1:]; the slice months[:] refers to the whole array.


//__________________________________________________________

func playWithSlicesOnceMore() {
// The built-in function make creates a slice of a specified element type, 
// length, and capacity. The capacity argument may be omitted, 
// in which case the capacity equals the length.
// 		make([]T, len)
// 		make([]T, len, cap) // same as make([]T, cap)[:len]
	
	s := make( []string, 3 )
	fmt.Printf("Slice Type: %T \n", s)

	fmt.Println("Slice: ", s)
	fmt.Println("Slice Length and Capacity: ", len(s), cap(s) )

	s[0] = "Ding"
	s[1] = "Dong"
	s[2] = "Ting"

	fmt.Println("Slice: ", s)
	fmt.Println("Slice Length and Capacity: ", len(s), cap(s) )

	s = append( s, "Tong" )
	fmt.Println("Slice: ", s)
	fmt.Println("Slice Length and Capacity: ", len(s), cap(s) )
	s = append( s, "Ming", "Mong" )	
	fmt.Println("Slice: ", s)
	fmt.Println("Slice Length and Capacity: ", len(s), cap(s) )
	s = append( s, "Modi")

	fmt.Println("Slice: ", s)
	fmt.Println("Slice Length and Capacity: ", len(s), cap(s) )
}

//__________________________________________________________

func playWithArrayAndSlicesConcepts() {
	numbers := [...]int{ 10, 20, 30, 40, 50, 60 }
	numbersCopy := numbers
	fmt.Println(" Numbers Length Capacity: ", len( numbers ), cap( numbers ) )
	fmt.Println(" NumbersCopy Length Capacity: ", len( numbersCopy ), cap( numbersCopy ) )

	fmt.Println( "Numbers: ", numbers )
	fmt.Println( "NumbersCopy: ", numbersCopy )
	numbers[ 0 ] = 99
	fmt.Println( "Numbers: ", numbers )
	fmt.Println( "NumbersCopy: ", numbersCopy )

	some := numbers[ 0 : 3 ]
	fmt.Println( "Some   : ", some )
	fmt.Println(" Some Length Capacity: ", len( some ), cap( some ) )

	some = append( some, 99 )
	fmt.Println( "Numbers: ", numbers )
	fmt.Println(" Numbers Length Capacity: ", len( numbers ), cap( numbers ) )
	fmt.Println( "Some   : ", some )
	fmt.Println(" Some Length Capacity: ", len( some ), cap( some ) )

	someCopy := some
	fmt.Println( "Some   : ", some )
	fmt.Println( "SomeCopy   : ", someCopy )
	some[0] = 777
	fmt.Println( "Some   : ", some )
	fmt.Println( "SomeCopy   : ", someCopy )

	//________________________________________

	// ss := [...]int{ 10, 20, 30, 40 }
	ss := make( []int, 4 )
	//ss = append(ss, 10, 20, 30, 40)
	ss[0] = 10
	ss[1] = 20
	ss[2] = 30
	ss[3] = 40
	cc := make( []int, len(ss) )

	fmt.Println("SS :", ss )
	fmt.Println("CC : ", cc )
	// cannot use ss (variable of type [4]int) as []int value in assignment
	// Shallow Copy i.e. Reference Assignment
	cc = ss
	fmt.Println("SS :", ss )
	fmt.Println("CC : ", cc )

	ss[3] = 777
	fmt.Println("SS :", ss )
	fmt.Println("CC : ", cc )

	dd := make( []int, len(ss ))
	// Deep Copy: Full Copy Of The Object Get Created
	copy( dd, ss )
	fmt.Println("SS :", ss )
	fmt.Println("DD : ", dd )

	ss[2] = 666
	fmt.Println("SS :", ss )
	fmt.Println("DD : ", dd )
	
}

//__________________________________________________________

func appendInt( x []int, y int ) []int {
	var z []int

	zlen := len( x ) + 1
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else {
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * len( x )
		}

		z = make( []int, zlen, zcap )
		copy( z, x )
	}

	z[ len( x )] = y
	return z
}

func playWithAppendInt() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendInt( x, i )
		fmt.Printf(" %d Capacity = %d \t %v \n", i, cap(y), y )
		x = y
	}
}

//__________________________________________________________
// Polymorphic Function
//		Using Varidiac Function

// Varidiac Function
//		Function With Variable Number Of Arguments
func summation( numbers ...int ) int {
	// fmt.Print( numbers )
	total := 0

	for _, number := range numbers {
		total = total + number
	}

	return total
}

func playWithSummation() {
	var result int

	result = summation()
	fmt.Println("Result : ", result )

	result = summation(11)
	fmt.Println("Result : ", result )

	result = summation(10, 20, 30, 40, 50)
	fmt.Println("Result : ", result )

	result = summation(10, 20, 30, 40, 50, 60, 80, 90)
	fmt.Println("Result : ", result )

	numbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	result = summation( numbers... )
	fmt.Println("Result : ", result )	
}

//__________________________________________________________


func appendSlice( x []int, y ...int ) [] int {
	var z []int

	zlen := len(x) + len(y)

	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else {
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x)
		}
		z = make( []int, zlen, zcap )
		copy(z, x)
	}
	copy( z[ len(x) : ], y )
	return z
}

func playWithAppendSlices() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendSlice(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
	fmt.Println( x )

	x = appendSlice(x, 10, 20, 30)
	fmt.Println( x )

	x = appendSlice(x, 11, 22, 33, 44, 55, 66)
	fmt.Println( x )

	numbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	x = appendSlice(x, numbers...)
	fmt.Println( x )	
}

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

func filterEmpty( strings []string ) []string {
	i := 0
	for _, s := range strings {
		if s != "" {
			strings[i] = s
			i++
		}
	}
	return strings[ : i ]
}

func filterEmptyAgain( strings []string ) []string {
	out := strings[ : 0 ] // Zero Length Slice Of Original
	for _, s := range strings {
		if s != "" {
			out = append( out, s )
		}
	}
	return out
}

func playWithNonEmpty() {
	data := []string{ "One", "", "Three", "Four", "", "Nice"}
	fmt.Printf( "%q \n", data )
	filteredData := filterEmpty( data )
	fmt.Printf( "%q \n", filteredData )

	dataAgain := []string{ "One", "", "Three", "Four", "", "Nice"}
	fmt.Printf( "%q \n", dataAgain )
	filteredDataAgain := filterEmptyAgain( dataAgain )
	fmt.Printf( "%q \n", filteredDataAgain )
}

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

// Maps Is Collection Of Key and Value Pairs
//	Map Syntax : map[ KeyType ]ValueType

func playWithMaps() {
    m := make( map[string]int )

    m["k1"] = 7  	// Storing 7 Value For Key "k1"
    m["k2"] = 13	// Storing 13 Value For Key "k2"

    fmt.Println("map:", m)

    v1 := m["k1"] 	// Getting Value For Key "k1"
    fmt.Println("v1: ", v1)

    fmt.Println("len:", len(m))

    delete(m, "k2")  // Deleting Key "k2" : Will Delete Key, Value Pair
    fmt.Println("map:", m)

    _, prs := m["k2"]  // Getting Value For Key "k2"
    fmt.Println("prs:", prs)

    // Declarative Syntax
    // 	To Create Map With Initialisation List
    n := map[string]int{"foo": 1, "bar": 2}
    fmt.Println("map:", n)
}

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

func removeDuplicates() {
	seen := make(map[string]bool) // a set of strings
	input := bufio.NewScanner(os.Stdin)
	for input.Scan() {
		line := input.Text()
		if !seen[line] {
			seen[line] = true
			fmt.Println(line)
		}
	}

	if err := input.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "removeDuplicates: %v\n", err)
		os.Exit(1)
	}	

	fmt.Println( seen )
}

//________________________________________________________________

// create and initialize maps
func playWithMaps1() {
	// Creating and initializing empty map
	// Using var keyword
	var map_1 map[int]int

	// Checking if the map is nil or not
	if map_1 == nil {
	
		fmt.Println("True")
	} else {
	
		fmt.Println("False")
	}

	// Creating and initializing a map
	// Using shorthand declaration and
	// using map literals
	map_2 := map[int]string{
	
			90: "Dog",
			91: "Cat",
			92: "Cow",
			93: "Bird",
			94: "Rabbit",
	}
	
	fmt.Println("Map-2: ", map_2)
}

//________________________________________________________________

// create and initialize a map
// Using make() function

func playWithMaps2() {
	// Creating a map
	// Using make() function
	var My_map = make(map[float64]string)
	fmt.Println(My_map)

	// As we already know that make() function
	// always returns a map which is initialized
	// So, we can add values in it
	My_map[1.3] = "Rohit"
	My_map[1.5] = "Sumit"
	fmt.Println(My_map)
}

//________________________________________________________________

// To iterate the map using for range loop
func playWithMaps3() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	// Iterating map using for range loop
	for id, pet := range m_a_p {
		fmt.Println(id, pet)
	}
}

//________________________________________________________________

// a key-value pair in the map using make() function
func playWithMaps4() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	fmt.Println("Original map: ", m_a_p)

	// Adding new key-value pairs in the map
	m_a_p[95] = "Parrot"
	m_a_p[96] = "Crow"
	fmt.Println("Map after adding new key-value pair:\n", m_a_p)

	// Updating values of the map
	m_a_p[91] = "PIG"
	m_a_p[93] = "DONKEY"
	fmt.Println("\nMap after updating values of the map:\n", m_a_p)
}

//________________________________________________________________

// retrieve the value of the key
func playWithMaps5() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}
	fmt.Println("Original map: ", m_a_p)

	// Retrieving values with the help of keys
	value_1 := m_a_p[90]
	value_2 := m_a_p[93]
	fmt.Println("Value of key[90]: ", value_1)
	fmt.Println("Value of key[93]: ", value_2)
}

//________________________________________________________________

// check the key is available or not
func playWithMaps6() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	fmt.Println("Original map: ", m_a_p)

	// Checking the key is available
	// or not in the m_a_p map
	pet_name, ok := m_a_p[90]
	fmt.Println("\nKey present or not:", ok)
	fmt.Println("Value:", pet_name)

	// Using blank identifier
	_, ok1 := m_a_p[92]
	fmt.Println("\nKey present or not:", ok1)
}

//________________________________________________________________

// Go program to illustrate how to delete a key
func playWithMaps7() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	fmt.Println("Original map: ", m_a_p)

	// Deleting keys
	// Using delete function
	delete(m_a_p, 90)
	delete(m_a_p, 93)

	fmt.Println("Map after deletion: ", m_a_p)
}

//________________________________________________________________

// modification concept in map
func playWithMaps8() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}
	fmt.Println("Original map: ", m_a_p)

	// Assigned the map into a new variable
	new_map := m_a_p

	// Perform modification in new_map
	new_map[96] = "Parrot"
	new_map[98] = "Pig"

	// Display after modification
	fmt.Println("New map: ", new_map)
	fmt.Println("\nModification done in old map:\n", m_a_p)
}

//________________________________________________________________

// Map Are References
func playWithMaps9() {
  var a = map[string]string{"brand": "Ford", "model": "Mustang", "year": "1964"}
  b := a

  fmt.Println(a)
  fmt.Println(b)

  b["year"] = "1970"
  fmt.Println("After change to b:")

  fmt.Println(a)
  fmt.Println(b)
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithTypesAndDefaultValues")
	playWithTypesAndDefaultValues()
	
	fmt.Println("\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction: playWithArraysAgain")
	playWithArraysAgain()

	fmt.Println("\nFunction: playWithArraysOnceAgain")
	playWithArraysOnceAgain()

	fmt.Println("\nFunction: playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\nFunction: playWithArrayAndSlicesAgain")
	playWithArrayAndSlicesAgain()

	fmt.Println("\nFunction: playWithArrayAndSlicesOnceAgain")
	playWithArrayAndSlicesOnceAgain()

	fmt.Println("\nFunction: playWithSlicesOnceMore")
	playWithSlicesOnceMore()

	fmt.Println("\nFunction: playWithArrayAndSlicesConcepts")
	playWithArrayAndSlicesConcepts()

	fmt.Println("\nFunction: playWithAppendInt")
	playWithAppendInt()

	fmt.Println("\nFunction: playWithSummation")
	playWithSummation()

	fmt.Println("\nFunction: playWithAppendSlices")
	playWithAppendSlices()

	fmt.Println("\nFunction: playWithNonEmpty")
	playWithNonEmpty()

	fmt.Println("\nFunction: playWithMaps")
	playWithMaps()

	// fmt.Println("\nFunction: removeDuplicates")
	// removeDuplicates()

	fmt.Println("\nFunction: playWithMaps1")
	playWithMaps1()

	fmt.Println("\nFunction: playWithMaps2")
	playWithMaps2()

	fmt.Println("\nFunction: playWithMaps3")
	playWithMaps3()

	fmt.Println("\nFunction: playWithMaps4")
	playWithMaps4()

	fmt.Println("\nFunction: playWithMaps5")
	playWithMaps5()

	fmt.Println("\nFunction: playWithMaps6")
	playWithMaps6()

	fmt.Println("\nFunction: playWithMaps7")
	playWithMaps7()

	fmt.Println("\nFunction: playWithMaps8")
	playWithMaps8()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


/*
_____________________________________________________________________
Codebunk Link:

https://codebunk.com/b/5351100681448/
https://codebunk.com/b/5351100681448/
_____________________________________________________________________
*/

