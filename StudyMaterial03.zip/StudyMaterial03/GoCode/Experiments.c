
#include <stdio.h>

void playWithArraysAndPointers() {
	int a[5] = {10, 20, 30, 40, 50};
	// printf("\n Something: %d", a[-5] );

	// for( int i = -10 ; i < 10 ; i++ ) {
	// 	printf("\n At Index %d Value : %d", i, a[i]);
	// }

	for( int i = 0 ; i < 5 ; i++ ) {
		// if i < 0 || i > 5 {
		// 	throw IndexOutOfBoundException
		// } else {
			printf("\n At Index %d Value : %d", i, a[i]);
		// }
	}

	int *ptr;
	ptr = a;
	for( int i = 0 ; i < 5 ; i++ ) {
		printf("\n At Index %d Value : %d", i, *(ptr + i) );
	}
}

int main() {
	printf("\nFunction: playWithArraysAndPointers");
	playWithArraysAndPointers();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");	
}
