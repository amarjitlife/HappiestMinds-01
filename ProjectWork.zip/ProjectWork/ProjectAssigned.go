
________________________________________________________________________________

THINGs ACTIONs Web Application
________________________________________________________________________________

0. Build Web Application With REST APIs

1. Admin Login
	Creation, Deletion, Listing and Filtering Of THING Data
	List THING and THING Details

2. User Login
	Listing and Filtering Of THINGs Data
	List THINGs and THING Details

3. THINGs ACTIONs and Order
	THINGs Selection, Ordering and Shopping Card

4. Rating The Services/THINGs

5. Preferred THINGs

6. Provision For Payments
	Provision For Payments Acceptance Methods
	
________________________________________________________________________________
________________________________________________________________________________

SNo	Full Name	OfficialEmailID	Project Title
1	Datti Rakesh	datti.rakesh@happiestminds.com	Cars Renting
2	kalla surya prakash	kalla.suryaprakash@happiestminds	Flights Booking
3	Jatin Gulati	jatin.gulati@happiestminds.com	Buses Booking
4	Gadi Sirisha	gadi.sirisha@happiestminds.com	Movies Booking
5	Gowthami G A	gowthami.a@happiestminds.com	Hotels Booking
6	Saumyaranjan Barik	saumyaranjan.barik@happiestminds.com	Doctors Booking
7	J V Anirudha	anirudha.jv@happiestminds.com	Bikes Purchasing
8	Mahanthi 	mahanthi.raj@happiestminds.com	Foods Booking
9	Thejashree H	thejashree.h@happiestminds.com	Books Renting
10	M Neeha	meenavalli.neeha@happiestminds.com	Restaurants Booking
11	Baratam Mojesh	baratam.mojesh@happiestminds.com	Groceries Booking
12	Apoorva	apoorvashetty@happiestminds.com	Trains Booking
13	Shubha H A	shubha.ha@happiestminds.com	Medical Tests Booking
14	Manish	manish@happiestminds.com	Sports And Fitness Booking
15	Sanmati Jain	sanmati.jain@happiestminds.com	Courier Management
16	Niranjan Aradhya P	niranjan.p@happiestminds.com	Shares and Equity Booking
17	Syed Tamzeed Ali	syed.ali@happiestminds.com	Fashion Purchase
18	Pooja Singh	pooja.singh4@happiestminds.com	Beverages Booking
19	Rosy Rupali	rosy.rupali@happiestminds.com	Meeting+Conference Booking
20	Akshat Mishra	akshat.mishra2@happiestminds.com	Missing
21	Yr Ravikumar	yr.ravikumar@happiestminds.com	Vehicle Parts Ordering
22	Lovedeep	lovedeep@happiestminds.com	Mutual Funds Ordering
23	Akshay Kumar	akshaybennur1@gmail.com	Electronics Ordering
24	Hanisha V LOkhande	hanishalokhande4@gmail.com	Inventory Management

________________________________________________________________________________
________________________________________________________________________________

